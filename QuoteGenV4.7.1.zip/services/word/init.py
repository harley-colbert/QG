from .handler import WordSubmissionHandler

__all__ = ["WordSubmissionHandler"]
