# Evidence Log Template

## Phase
- Phase name:
- Date/time:
- Agent:

## Summary of changes
- Files added:
- Files modified:
- Files deleted:

## Key implementation notes
- (short bullets)

## Tests run
- Manual steps:
- Console output / errors:

## Screenshots / artifacts
- (paths or notes)

## Exit checklist confirmation
- [ ] Phase success checklist verified
