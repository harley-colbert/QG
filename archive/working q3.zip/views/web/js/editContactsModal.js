import { addAllianceContact, updateAllianceContact } from './apiWrapper.js';

const EDIT_CONTACTS_HTML_PATH = 'admin/editContacts.html';
let editModalLoaded = false;
let afterSaveCallback = null;

export async function ensureEditContactModalLoaded() {
  if (!editModalLoaded) {
    const resp = await fetch(EDIT_CONTACTS_HTML_PATH);
    if (!resp.ok) throw new Error('Failed to load editContacts.html');
    const doc = new DOMParser().parseFromString(await resp.text(), 'text/html');
    const modal = doc.querySelector('#edit-contacts-modal');
    if (!modal) throw new Error('No #edit-contacts-modal in editContacts.html');
    document.getElementById('edit-contacts-modal-body').innerHTML = '';
    document.getElementById('edit-contacts-modal-body').appendChild(modal);
    setupEditContactModalListeners();
    editModalLoaded = true;
  }
}

export function showEditContactModal(contact = null, onSave = null) {
  const modal = document.getElementById('edit-contacts-modal');
  if (!modal) { console.error('No #edit-contacts-modal found'); return; }
  afterSaveCallback = typeof onSave === 'function' ? onSave : null;
  const form = document.getElementById('contact-form');
  if (form) form.reset();
  document.getElementById('modal-title').textContent = contact && contact.id ? 'Edit Contact' : 'Add Contact';
  document.getElementById('contact-id').value = contact && contact.id ? contact.id : '';
  document.getElementById('contact-name').value = contact && contact.name ? contact.name : '';
  document.getElementById('contact-title').value = contact && contact.title ? contact.title : '';
  document.getElementById('contact-cell').value = contact && contact.phone ? contact.phone : '';
  document.getElementById('contact-email').value = contact && contact.email ? contact.email : '';
  modal.style.display = 'flex';
}

export function hideEditContactModal() {
  const modal = document.getElementById('edit-contacts-modal');
  if (!modal) return;
  modal.style.display = 'none';
  afterSaveCallback = null;
}

export function setupEditContactModalListeners() {
  const modal = document.getElementById('edit-contacts-modal');
  if (!modal) return;

  const saveBtn = document.getElementById('save-contact');
  if (saveBtn) saveBtn.onclick = async function () {
    const id = document.getElementById('contact-id').value.trim();
    const name = document.getElementById('contact-name').value.trim();
    const title = document.getElementById('contact-title').value.trim();
    const phone = document.getElementById('contact-cell').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    if (!name || !title || !phone || !email) {
      alert('Please fill out all fields.'); return;
    }
    const contact = { id: id ? Number(id) : undefined, name, title, phone, email };
    try {
      if (contact.id) await updateAllianceContact(contact);
      else await addAllianceContact(contact);
      hideEditContactModal();
      if (afterSaveCallback) afterSaveCallback(contact);
    } catch (e) {
      alert('Failed to save contact.');
    }
  };

  const cancelBtn = document.getElementById('cancel-edit-contact');
  if (cancelBtn) cancelBtn.onclick = hideEditContactModal;

  const closeBtn = document.getElementById('close-edit-contact');
  if (closeBtn) closeBtn.onclick = hideEditContactModal;

  const form = document.getElementById('contact-form');
  if (form) form.onsubmit = e => { e.preventDefault(); };
}
