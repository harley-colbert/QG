// viewStore.js
// Centralised data stores and active field registry

/**
 * Flat, per‑quote‑type cache of fieldKey → string.
 */
export const viewStore = {
  budgetary: {},
  final: {}
};

/**
 * Registered active field keys (inputs, selects, textareas, Quill editors).
 */
export const activeFieldKeys = new Set();

/**
 * Map of Quill editors keyed by fieldKey.
 */
export const quillInstances = {};

/**
 * Register a field so saveViewStore knows to include it.
 * @param {string} fieldKey
 */
export function registerField(fieldKey) {
  activeFieldKeys.add(fieldKey);
}

/**
 * Unregister a field when it’s removed from the DOM.
 * Also cleans up stored values.
 * @param {string} fieldKey
 */
export function unregisterField(fieldKey) {
  activeFieldKeys.delete(fieldKey);
  // Remove any saved snapshot
  Object.keys(viewStore).forEach(type => {
    delete viewStore[type][fieldKey];
  });
  // Also unregister Quill if present
  if (quillInstances[fieldKey]) delete quillInstances[fieldKey];
}

/**
 * Link a newly created Quill editor to its fieldKey and register it.
 * @param {string} fieldKey
 * @param {Quill} quill
 */
export function registerQuill(fieldKey, quill) {
  quillInstances[fieldKey] = quill;
  registerField(fieldKey);
}

/**
 * Unregister a Quill editor when its field is removed.
 * @param {string} fieldKey
 */
export function unregisterQuill(fieldKey) {
  delete quillInstances[fieldKey];
  unregisterField(fieldKey);
}

/**
 * Apply stored values back into the form.
 * @param {string} type – "budgetary" or "final"
 */
export function applyViewStore(type) {
  const data = viewStore[type] || {};
  // plain form controls
  Object.entries(data).forEach(([fieldKey, val]) => {
    const el =
      document.querySelector(`[data-field-key="${fieldKey}"]`) ||
      document.querySelector(`[name="${fieldKey}"]`);
    if (el && !(el.tagName === 'DIV' && quillInstances[fieldKey])) {
      el.value = val;
    }
  });
  // Quill editors
  Object.entries(quillInstances).forEach(([fieldKey, quill]) => {
    if (data[fieldKey] != null) {
      quill.clipboard.dangerouslyPasteHTML(data[fieldKey], 'silent');
    }
  });
}

/**
 * Snapshot all active fields (and OEE cards + Quills) into viewStore.
 * @param {string} type
 */
export function saveViewStore(type) {
  const snapshot = {};

  // A) Named form controls for registered fields
  activeFieldKeys.forEach(fieldKey => {
    const el =
      document.querySelector(`[data-field-key="${fieldKey}"]`) ||
      document.querySelector(`[name="${fieldKey}"]`);
    if (!el) return;
    if (['INPUT','SELECT','TEXTAREA'].includes(el.tagName)) {
      snapshot[fieldKey] = el.value ?? '';
    }
  });

  // B) OEE stat-cards
  document.querySelectorAll('.oee-card').forEach(card => {
    const key = card.id;
    const span = card.querySelector('.big');
    if (!span) return;
    let val = span.textContent.trim();
    if (val.endsWith('%')) val = val.slice(0,-1).trim();
    snapshot[key] = val;
  });

  // C) Quill editors
  Object.entries(quillInstances).forEach(([fieldKey, quill]) => {
    if (!quill || !quill.root) return;
    snapshot[fieldKey] = quill.root.innerHTML;
  });

  viewStore[type] = snapshot;
}
