import { getAllianceContacts, deleteAllianceContact } from './apiWrapper.js';
import { showEditContactModal, ensureEditContactModalLoaded } from './editContactsModal.js';

const CONTACTS_HTML_PATH = 'admin/contacts.html';
let contactsLoaded = false;
let contactList = [];

export async function loadContactsModal() {
  // Only inject once unless you want to always reload
  if (!contactsLoaded) {
    const resp = await fetch(CONTACTS_HTML_PATH);
    if (!resp.ok) {
      console.error('Failed to load contacts.html:', resp.status);
      return;
    }
    const doc = new DOMParser().parseFromString(await resp.text(), 'text/html');
    const modal = doc.querySelector('#contacts-modal');
    if (!modal) {
      console.error('No #contacts-modal in contacts.html');
      return;
    }
    // Empty the body and inject
    const body = document.getElementById('contacts-modal-body');
    body.innerHTML = '';
    body.appendChild(modal);
    contactsLoaded = true;
  }

  // Wire up close and toolbar
  const modal = document.getElementById('contacts-modal');
  const closeBtn = document.getElementById('close-contacts');
  if (closeBtn) closeBtn.onclick = () => (modal.style.display = 'none');
  const btnClose = document.getElementById('btn-close-contacts');
  if (btnClose) btnClose.onclick = () => (modal.style.display = 'none');

  const addBtn = document.getElementById('add-contact');
  if (addBtn) addBtn.onclick = async () => {
    await ensureEditContactModalLoaded();
    showEditContactModal(null, async () => { await refreshContactsTable(); });
  };

  const refreshBtn = document.getElementById('refresh-contacts');
  if (refreshBtn) refreshBtn.onclick = async () => { await refreshContactsTable(); };

  await refreshContactsTable();

  // Show the modal
  modal.style.display = 'flex';
}

export async function refreshContactsTable() {
  contactList = await getAllianceContacts();
  const tbody = document.querySelector('#contacts-table tbody');
  if (!tbody) {
    console.error('No #contacts-table tbody');
    return;
  }
  tbody.innerHTML = '';
  contactList.forEach(c => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${c.name}</td>
      <td>${c.title || ''}</td>
      <td>${c.phone || ''}</td>
      <td>${c.email || ''}</td>
      <td>
        <button class="action-btn edit" data-id="${c.id}">Edit</button>
        <button class="action-btn delete" data-id="${c.id}">Delete</button>
      </td>`;
    tbody.appendChild(tr);
  });

  tbody.querySelectorAll('button.edit').forEach(btn => {
    btn.onclick = async () => {
      const contact = contactList.find(x => String(x.id) === String(btn.dataset.id));
      await ensureEditContactModalLoaded();
      showEditContactModal(contact, async () => { await refreshContactsTable(); });
    };
  });

  tbody.querySelectorAll('button.delete').forEach(btn => {
    btn.onclick = async () => {
      if (!confirm('Delete this contact?')) return;
      await deleteAllianceContact(Number(btn.dataset.id));
      await refreshContactsTable();
    };
  });
}
