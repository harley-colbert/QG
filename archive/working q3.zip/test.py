import tkinter as tk
from tkinter import filedialog, scrolledtext, messagebox
from docx import Document
import re
import os
import xml.etree.ElementTree as ET

TAG_PATTERNS = [
    re.compile(r'{{\s*(.*?)\s*}}'),
    re.compile(r'{%\s*(.*?)\s*%}')
]

def merge_jinja_runs(doc):
    merged_count = 0
    for para in doc.paragraphs:
        para_text = ''.join(run.text for run in para.runs)
        if (('{{' in para_text or '{%' in para_text) and len(para.runs) > 1):
            while len(para.runs) > 1:
                para._element.remove(para.runs[-1]._element)
            para.runs[0].text = para_text
            merged_count += 1
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    para_text = ''.join(run.text for run in para.runs)
                    if (('{{' in para_text or '{%' in para_text) and len(para.runs) > 1):
                        while len(para.runs) > 1:
                            para._element.remove(para.runs[-1]._element)
                        para.runs[0].text = para_text
                        merged_count += 1
    return doc, merged_count

def extract_jinja_tags_from_doc(doc):
    report = []
    for p_idx, para in enumerate(doc.paragraphs):
        for pat in TAG_PATTERNS:
            for match in pat.finditer(para.text):
                report.append({
                    'location': f'Paragraph {p_idx+1}',
                    'raw_tag': match.group(0),
                    'inner': match.group(1)
                })
    for t_idx, table in enumerate(doc.tables):
        for r_idx, row in enumerate(table.rows):
            for c_idx, cell in row.cells:
                for p_idx, para in enumerate(cell.paragraphs):
                    for pat in TAG_PATTERNS:
                        for match in pat.finditer(para.text):
                            report.append({
                                'location': f'Table {t_idx+1}, Row {r_idx+1}, Cell {c_idx+1}, Paragraph {p_idx+1}',
                                'raw_tag': match.group(0),
                                'inner': match.group(1)
                            })
    return report

def parse_xml_keys(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    all_keys = set()

    def recurse(elem, path=''):
        tag = elem.tag
        new_path = f'{path}.{tag}' if path else tag
        all_keys.add("data." + new_path)
        for child in elem:
            recurse(child, new_path)

    recurse(root)
    return all_keys

def analyze_docx_tags(docx_path, xml_path):
    doc = Document(docx_path)
    doc, merged_count = merge_jinja_runs(doc)
    tag_report = extract_jinja_tags_from_doc(doc)
    keys = parse_xml_keys(xml_path)
    return tag_report, merged_count, keys

def select_files_and_analyze(output_widget):
    docx_path = filedialog.askopenfilename(filetypes=[('Word Documents', '*.docx')], title="Select Word Document")
    if not docx_path:
        return
    xml_path = filedialog.askopenfilename(filetypes=[('XML Files', '*.xml')], title="Select XML Data File")
    if not xml_path:
        return
    try:
        report, merged_count, xml_keys = analyze_docx_tags(docx_path, xml_path)
        output_widget.delete(1.0, tk.END)
        output_widget.insert(tk.END, f"Scanned file: {os.path.basename(docx_path)}\n")
        output_widget.insert(tk.END, f"Against dataset: {os.path.basename(xml_path)}\n\n")
        output_widget.insert(tk.END, f"Merged runs in {merged_count} paragraphs/cells with Jinja2 tags.\n")
        output_widget.insert(tk.END, f"Found {len(report)} Jinja2 tags in merged document:\n")
        unique_tags = set(item['inner'] for item in report)
        output_widget.insert(tk.END, f"(Unique tags: {len(unique_tags)})\n\n")

        missing = []
        for idx, entry in enumerate(report, 1):
            tag_expr = entry['inner']
            if tag_expr.startswith("data."):
                base_key = tag_expr.split('|')[0].strip().split('[')[0].replace("['", ".").replace("']", "")
                if base_key not in xml_keys:
                    output_widget.insert(tk.END, f"{idx:3}: ❌ {entry['location']}: {entry['raw_tag']} (Missing: {base_key})\n")
                    missing.append(base_key)
                else:
                    output_widget.insert(tk.END, f"{idx:3}: ✅ {entry['location']}: {entry['raw_tag']}\n")
            else:
                output_widget.insert(tk.END, f"{idx:3}: ⚠️  {entry['location']}: {entry['raw_tag']} (Non-data tag)\n")

        if missing:
            output_widget.insert(tk.END, f"\n❌ Missing keys in XML dataset: {len(set(missing))}\n")
            for m in sorted(set(missing)):
                output_widget.insert(tk.END, f"   - {m}\n")
        else:
            output_widget.insert(tk.END, "\n✅ All Jinja2 data tags are present in the XML dataset.\n")

    except Exception as e:
        messagebox.showerror("Error", f"Failed to analyze document:\n{e}")

def main():
    root = tk.Tk()
    root.title("Jinja2 Word Tag vs XML Dataset Checker")
    root.geometry('950x700')
    tk.Button(root, text="Select Word Doc and XML to Scan", command=lambda: select_files_and_analyze(output)).pack(pady=10)
    output = scrolledtext.ScrolledText(root, font=('Consolas', 10), wrap=tk.WORD)
    output.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    root.mainloop()

if __name__ == "__main__":
    main()
