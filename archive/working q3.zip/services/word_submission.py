import os
import re
import logging
import tempfile
from datetime import datetime
from typing import Any, Callable, Optional, Dict

import pythoncom
import win32com.client as win32
from docxtpl import DocxTemplate
from docx import Document
from docx.shared import Mm
from PIL import Image
from bs4 import BeautifulSoup

# Configure logging for this module
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
if not logger.hasHandlers():
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

def strip_markup(text):
    """Strip all HTML/XML tags from a string value."""
    if not isinstance(text, str):
        return text
    return BeautifulSoup(text, "html.parser").get_text()

def sanitize_context(obj):
    """
    Recursively sanitize all strings in dict/list by stripping HTML/XML tags.
    """
    if isinstance(obj, dict):
        return {k: sanitize_context(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [sanitize_context(i) for i in obj]
    elif isinstance(obj, str):
        return strip_markup(obj)
    else:
        return obj

class WordSubmissionHandler:
    """
    Handles Word document submission based on a template.
    This class encapsulates all document–related processing steps:
      1. Loading a Word template from disk.
      2. Rendering text markers in the template using Jinja2 (via DocxTemplate).
      3. Replacing custom image markers with actual images.
      4. Inserting page breaks (using COM automation on Windows).
      5. Saving the final document.
    An optional status callback can be provided to relay progress updates.
    """
    
    def __init__(self, template_path: str, status_callback: Optional[Callable[[str], None]] = None) -> None:
        """
        Initialize the handler with the specified template path and an optional status callback.
        Args:
            template_path (str): Path to the Word template file.
            status_callback (Optional[Callable[[str], None]]): Function to receive status updates.
        """
        self.template_path = template_path
        self.status_callback = status_callback
        self.doc: Optional[Document] = None           # Document instance for direct manipulation
        self.tpl: Optional[DocxTemplate] = None         # DocxTemplate instance for Jinja2 rendering
        self.context: dict = {}                         # Context 
        self._send_status(f"WordSubmissionHandler initialized with template: {template_path}")

    def _send_status(self, message: str) -> None:
        """Send status messages via the callback and log the message."""
        if self.status_callback:
            self.status_callback(message)
        logger.info(message)

    def _get_nested_context_value(self, context: dict, key: str) -> Any:
        """
        Retrieve a nested value from the provided context dictionary using dot notation.
        Args:
            context (dict): The context dictionary.
            key (str): Dot-separated key string (e.g., 'data.customercontact.name').
        Returns:
            Any: The corresponding value if found, else None.
        """
        keys = key.split('.')
        value = context
        try:
            for k in keys:
                value = value[k]
            return value
        except (KeyError, TypeError):
            logger.warning(f"Key '{key}' not found in context.")
            return None

    def load_template(self) -> None:
        """
        Load the Word template from disk into both a python-docx Document and a DocxTemplate.
        Raises:
            FileNotFoundError: If the template file does not exist.
        """
        self._send_status("Loading Word template...")
        if not os.path.isfile(self.template_path):
            raise FileNotFoundError(f"Template file not found: {self.template_path}")
        try:
            self.doc = Document(self.template_path)
            self.tpl = DocxTemplate(self.template_path)
            self._send_status("Template loaded successfully.")
        except Exception as e:
            logger.exception("Error loading template.")
            raise e

    def render_template(self, context: dict) -> None:
        """
        Render the template by replacing Jinja2 text markers with values from the provided context.
        For OEE metrics, numeric values are optionally suffixed with '%'.
        Args:
            context (dict): Dictionary of values keyed by dot notation.
        """
        self._send_status("Rendering template with provided context...")
        # Sanitize context: remove HTML/XML from ALL strings
        clean_context = sanitize_context(context)
        # Optionally adjust OEE-related values: append '%' to numeric OEE metrics
        for key, value in clean_context.items():
            if "oee" in key.lower() and isinstance(value, (int, float)):
                clean_context[key] = f"{value}%"
        try:
            if self.tpl is None:
                raise ValueError("Template not loaded. Call load_template() first.")
            self.tpl.render(clean_context)
            # Save rendered template to a temporary file and reload into self.doc
            temp_file = os.path.join(tempfile.gettempdir(), "temp_rendered.docx")
            self.tpl.save(temp_file)
            self.doc = Document(temp_file)
            self._send_status("Template rendered successfully.")
        except Exception as e:
            logger.exception("Error rendering template.")
            raise e

    def replace_image_markers(self, context: dict, image_width_mm: int = 50) -> None:
        """
        Replace custom image markers in the document with actual images.
        Markers must be in the format: [[ Image: key ]]
        where 'key' is used to lookup the image file path in the context.
        Args:
            context (dict): The context dictionary containing image file paths.
            image_width_mm (int): Desired image width in millimeters (default 50).
        """
        self._send_status("Replacing image markers...")
        image_marker_pattern = re.compile(r"\[\[\s*[Ii]mage:?\s*([^\]]+)\s*\]\]")
        try:
            if self.doc is None:
                raise ValueError("Document not loaded. Call load_template() first.")
            for paragraph in self.doc.paragraphs:
                matches = image_marker_pattern.findall(paragraph.text)
                for match in matches:
                    image_key = match.strip()
                    image_path = self._get_nested_context_value(context, image_key)
                    if not image_path:
                        logger.error(f"No image path found for key: {image_key}")
                        continue
                    if not os.path.isfile(image_path):
                        logger.error(f"Image file not found: {image_path}")
                        continue
                    # Remove marker text and insert picture
                    marker_text = f"[[ Image: {image_key} ]]"
                    paragraph.text = paragraph.text.replace(marker_text, "")
                    run = paragraph.add_run()
                    run.add_picture(image_path, width=Mm(image_width_mm))
                    logger.info(f"Inserted image for key '{image_key}' from path: {image_path}")
            self._send_status("Image markers replaced successfully.")
        except Exception as e:
            logger.exception("Error replacing image markers.")
            raise e

    def insert_page_breaks(self, file_path: str) -> None:
        """
        Insert page breaks into the document via COM automation.
        This method opens the document using Win32 COM, then inserts page breaks before headings.
        Args:
            file_path (str): Path to the document file to modify.
        """
        self._send_status("Inserting page breaks...")
        try:
            pythoncom.CoInitialize()
            word = win32.gencache.EnsureDispatch('Word.Application')
            word.Visible = False
            doc = word.Documents.Open(file_path)
            page_setup = doc.PageSetup
            page_height = page_setup.PageHeight
            bottom_threshold = page_height * 0.75  # Bottom 25% threshold
            # For demonstration, iterate over paragraphs and insert a page break before each heading.
            for paragraph in doc.Paragraphs:
                style_name = paragraph.Style.NameLocal
                if "Heading" in style_name:
                    paragraph.Range.InsertBreak(Type=win32.constants.wdPageBreak)
            doc.Save()
            doc.Close()
            word.Quit()
            self._send_status("Page breaks inserted successfully.")
        except Exception as e:
            logger.exception("Error inserting page breaks.")
            raise e

    def save_document(self, output_path: str) -> None:
        """
        Save the current document to the specified output file.
        Args:
            output_path (str): Destination file path.
        """
        self._send_status("Saving document...")
        try:
            if self.doc is None:
                raise ValueError("No document to save. Ensure the template is loaded and processed.")
            self.doc.save(output_path)
            self._send_status(f"Document saved successfully at: {output_path}")
        except Exception as e:
            logger.exception("Error saving document.")
            raise e


