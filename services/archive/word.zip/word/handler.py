# services/word/handler.py
from __future__ import annotations

import os
import tempfile
from typing import Any, Callable, Optional, List

from docxtpl import DocxTemplate
from docx import Document

from .constants import logger, LOG_PREFIX
from .sanitize import sanitize_except_exceptions
from .quill_convert import looks_like_quill_delta, delta_to_html
from .images import replace_image_markers
from .pagination import insert_page_breaks_by_vertical_position
from .html_shim import ensure_html_wrapper_initialized, add_html_wrapper

class WordSubmissionHandler:
    """
    Orchestrates:
      1) Sanitize context (only EXCEPTION_HTML_FIELDS remain rich)
      2) Convert rich strings (HTML or Quill Delta) into Subdocs
      3) Render template with docxtpl
      4) Replace [[ Image: key ]] markers
      5) Insert pagination page breaks via COM
    """

    def __init__(
        self,
        template_path: str,
        status_callback: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.template_path = template_path
        self.status_callback = status_callback
        self.doc: Optional[Document] = None
        self.tpl: Optional[DocxTemplate] = None
        ensure_html_wrapper_initialized()  # make sure html shim is ready
        logger.debug(f"{LOG_PREFIX} __init__: template_path={template_path!r}")

    # ---------------- misc ----------------
    def send_status(self, message: str) -> None:
        msg = f"{LOG_PREFIX} {message}"
        if self.status_callback:
            self.status_callback(msg)
        logger.info(msg)

    def load_template(self) -> None:
        self.send_status("Loading Word template...")
        if not os.path.isfile(self.template_path):
            raise FileNotFoundError(f"Template file not found: {self.template_path}")
        self.tpl = DocxTemplate(self.template_path)
        self.send_status("Template loaded successfully.")

    # ---------------- core ----------------
    def _build_subdoc_from_html(self, html: str):
        """
        Create a docxtpl Subdoc and inject HTML into it using the html shim.
        """
        if not self.tpl:
            raise RuntimeError("Template not loaded.")
        ensure_html_wrapper_initialized()  # belt & suspenders
        sub = self.tpl.new_subdoc()
        add_html_wrapper(sub, html)
        return sub

    def _transform_exceptions_to_subdocs(self, obj: Any, path: Optional[List[str]] = None) -> Any:
        """
        Walk sanitized context; for paths in EXCEPTION_HTML_FIELDS convert the string
        (HTML or Quill Delta) into a Subdoc object.
        """
        from .constants import EXCEPTION_HTML_FIELDS
        if path is None:
            path = []
        if isinstance(obj, dict):
            out = {}
            for k, v in obj.items():
                full = ".".join(path + [k]).lower()
                if full in EXCEPTION_HTML_FIELDS and isinstance(v, str):
                    html = v
                    if looks_like_quill_delta(v):
                        try:
                            html = delta_to_html(v)
                        except Exception as e:
                            from .sanitize import strip_markup
                            logger.warning(f"{LOG_PREFIX} Delta→HTML failed at {full}: {e}; falling back to plain.")
                            html = f"<p>{strip_markup(v)}</p>"
                    out[k] = self._build_subdoc_from_html(html)
                else:
                    out[k] = self._transform_exceptions_to_subdocs(v, path + [k])
            return out
        elif isinstance(obj, list):
            return [self._transform_exceptions_to_subdocs(v, path) for v in obj]
        else:
            return obj

    # ---------------- public API ----------------
    def render_document(self, context: dict, output_path: str):
        logger.info(f"{LOG_PREFIX} [Render_Content] keys={list(context.keys())} output_path={output_path!r}")

        # 1) Sanitize plain fields (non-exception paths)
        self.send_status("Step 1: Sanitizing context (non-exception fields → plain)...")
        sanitized_context = sanitize_except_exceptions(context)

        # 2) Load template
        self.send_status("Step 2: Loading DOCX template...")
        self.load_template()

        # 3) Convert rich fields (HTML/Delta) to Subdocs
        self.send_status("Step 3: Converting rich fields to Subdocs (HTML → Word)...")
        context_for_tpl = self._transform_exceptions_to_subdocs(sanitized_context)

        # 4) Render docxtpl placeholders (Subdocs land in-place)
        self.send_status("Step 4: Rendering DOCX template with docxtpl...")
        assert self.tpl is not None
        self.tpl.render(context_for_tpl)

        temp_doc_path = os.path.join(tempfile.gettempdir(), "temp_rendered.docx")
        self.send_status(f"Step 5: Saving rendered document to {temp_doc_path}")
        self.tpl.save(temp_doc_path)

        # 5) Replace image markers in-place
        self.send_status("Step 6: Replacing image markers...")
        self.doc = Document(temp_doc_path)
        replace_image_markers(self.doc, context)

        temp_after_images = os.path.join(tempfile.gettempdir(), "temp_after_images.docx")
        self.send_status(f"Step 7: Saving after image replacement to {temp_after_images}")
        self.doc.save(temp_after_images)

        # 6) Insert page breaks (COM-based pagination)
        self.send_status("Step 8: Inserting page breaks based on vertical position...")
        #insert_page_breaks_by_vertical_position(temp_after_images, 7.25)

        # 7) Final save
        self.doc = Document(temp_after_images)
        self.send_status(f"Step 9: Final save to {output_path}...")
        self.doc.save(output_path)
        self.send_status(f"Document fully processed and saved to {output_path}")
