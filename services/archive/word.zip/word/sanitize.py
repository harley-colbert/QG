# services/word/sanitize.py
from typing import Any, List, Optional
import warnings
from bs4 import BeautifulSoup
from bs4 import MarkupResemblesLocatorWarning

from .constants import EXCEPTION_HTML_FIELDS, logger, LOG_PREFIX

# Silence: "The input looks more like a filename than markup."
warnings.filterwarnings("ignore", category=MarkupResemblesLocatorWarning)

def strip_markup(text: Any) -> Any:
    if not isinstance(text, str):
        return text
    stripped = BeautifulSoup(text, "html.parser").get_text()
    logger.debug(f"{LOG_PREFIX} strip_markup: in_len={len(text)} out_len={len(stripped)}")
    return stripped

def sanitize_except_exceptions(obj: Any, parent_path: Optional[List[str]] = None) -> Any:
    if parent_path is None:
        parent_path = []
    if isinstance(obj, dict):
        clean = {}
        for k, v in obj.items():
            path = parent_path + [k]
            full_path = ".".join(path).lower()
            if full_path in EXCEPTION_HTML_FIELDS:
                logger.debug(f"{LOG_PREFIX} sanitize: KEEP-RICH path={full_path}")
                clean[k] = v
            else:
                clean[k] = sanitize_except_exceptions(v, path)
        return clean
    elif isinstance(obj, list):
        return [sanitize_except_exceptions(item, parent_path) for item in obj]
    elif isinstance(obj, str):
        s = strip_markup(obj)
        if s != obj:
            logger.debug(f"{LOG_PREFIX} sanitize: STRIPPED len_in={len(obj)} len_out={len(s)}")
        return s
    else:
        return obj
