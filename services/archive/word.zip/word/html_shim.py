# services/word/html_shim.py
# HTML -> Word bridge using ONLY html-for-docx (no fallbacks).
# - Ensures 'List Bullet X' / 'List Number X' styles exist (1..9).
# - Converts Quill ql-indent-N to nested UL/OL trees and strips orphan <a>.
# - PRESERVES NESTING (does NOT flatten to 'List Paragraph').
# - NEW: Maintains list level RELATIVE to the template marker's list level.

from __future__ import annotations
from typing import Any, Iterable, Optional, Tuple

from docx.document import Document as _DocxDocument
from docx.enum.style import WD_STYLE_TYPE
from docx.text.paragraph import Paragraph

from .constants import logger, LOG_PREFIX
from utilities.quill_lists import normalize_quill_lists  # also strips orphan anchors

# Require html-for-docx
try:
    import html4docx  # type: ignore
except Exception as e:  # pragma: no cover
    raise ImportError(
        f"{LOG_PREFIX} html-for-docx is required. Install with:\n"
        "    pip install html-for-docx\n"
        f"Original import error: {e}"
    )

_parser = html4docx.HtmlToDocx()

# ---------- toggles ----------

# NEVER flatten to 'List Paragraph' by default.
FORCE_LIST_PARAGRAPH_STYLE = False  # kept for compatibility; must remain False.

# Keep style names aligned with actual levels (purely cosmetic & safe).
SYNC_STYLE_TO_LEVEL = True

# NEW: when True, shift Quill list levels by the anchor marker's level.
# Anchor = paragraph immediately BEFORE the first inserted paragraph.
RELATIVE_TO_ANCHOR_LEVEL = True

# If True, only apply relative shifting when the paragraph's list FAMILY
# (bullet vs number) matches the anchor's family. If False, apply to both.
RELATIVE_ONLY_WHEN_FAMILY_MATCHES = True


# ---------- helpers ----------

def _unwrap_to_docx_document(doc_like: Any) -> _DocxDocument:
    """
    Return a real python-docx Document.
    Accepts python-docx Document or docxtpl Subdoc-like objects exposing an inner Document.
    """
    if isinstance(doc_like, _DocxDocument):
        return doc_like

    for attr in ("subdocx", "docx", "document", "_subdocx", "_docx", "_document"):
        inner = getattr(doc_like, attr, None)
        if isinstance(inner, _DocxDocument):
            return inner

    raise TypeError(
        f"{LOG_PREFIX} Expected a python-docx Document; got {type(doc_like)!r}. "
        "If this is a docxtpl Subdoc, ensure it exposes an underlying Document."
    )


def _get_style(doc: _DocxDocument, name: str):
    try:
        return doc.styles[name]
    except KeyError:
        return None


def _ensure_para_style(doc: _DocxDocument, name: str, base_name: str | None = None):
    """
    Ensure a paragraph style 'name' exists. If missing, create it, optionally
    using 'base_name' as its base style.
    """
    s = _get_style(doc, name)
    if s is not None:
        return s

    s = doc.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
    if base_name:
        base = _get_style(doc, base_name)
        if base is not None:
            try:
                s.base_style = base
            except Exception:
                pass
    logger.debug(f"{LOG_PREFIX} created paragraph style: {name} (base={base_name})")
    return s


def _ensure_list_styles(doc: _DocxDocument) -> None:
    """
    html-for-docx may request:
      - 'List Bullet', 'List Bullet 2'...'List Bullet 9'
      - 'List Number', 'List Number 2'...'List Number 9'
    Make sure they all exist, chained to 'List Paragraph' (or 'Normal' if needed).
    """
    _ensure_para_style(doc, "Normal", None)
    _ensure_para_style(doc, "List Paragraph", "Normal")

    families = ("List Bullet", "List Number")
    levels = [""] + [f" {i}" for i in range(2, 10)]  # "", " 2", ..., " 9"

    for root in families:
        # Level 1
        _ensure_para_style(doc, root, "List Paragraph")
        # Levels 2-9 inherit from level 1 of the same family
        for suffix in levels[1:]:
            _ensure_para_style(doc, f"{root}{suffix}", root)


def _iter_all_paragraphs(doc: _DocxDocument) -> Iterable[Paragraph]:
    # Document-level paragraphs
    for p in doc.paragraphs:
        yield p
    # Table cell paragraphs
    for tbl in doc.tables:
        for row in tbl.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    yield p


def _style_name_to_family_and_level(style_name: str) -> Optional[Tuple[str, int]]:
    """
    Map paragraph style name to (family, ilvl) if it's a list style, else None.
    Examples:
      'List Bullet'   -> ('bullet', 0)
      'List Bullet 2' -> ('bullet', 1)
      'List Number'   -> ('number', 0)
      'List Number 3' -> ('number', 2)
    """
    if style_name.startswith("List Bullet"):
        if style_name == "List Bullet":
            return ("bullet", 0)
        try:
            # Expecting "List Bullet N"
            n = int(style_name.split()[-1])
            return ("bullet", max(0, n - 1))
        except Exception:
            return ("bullet", 0)
    if style_name.startswith("List Number"):
        if style_name == "List Number":
            return ("number", 0)
        try:
            n = int(style_name.split()[-1])
            return ("number", max(0, n - 1))
        except Exception:
            return ("number", 0)
    return None


def _family_and_level_to_style_name(family: str, ilvl: int) -> str:
    """
    Convert (family, ilvl) to a paragraph style name.
      ('bullet', 0) -> 'List Bullet'
      ('bullet', 2) -> 'List Bullet 3'
      ('number', 0) -> 'List Number'
      ('number', 4) -> 'List Number 5'
    """
    base = "List Bullet" if family == "bullet" else "List Number"
    if ilvl <= 0:
        return base
    level_num = min(ilvl, 8) + 1  # ilvl 0..8 -> style 1..9
    return f"{base} {level_num}"


def _relabel_list_styles_to_list_paragraph(doc: _DocxDocument) -> None:
    """
    (Legacy) Replace any 'List Bullet*'/'List Number*' styles with 'List Paragraph'
    while keeping numbering/bullets. Disabled by default.
    """
    lp = _get_style(doc, "List Paragraph") or _ensure_para_style(doc, "List Paragraph", "Normal")
    renamed = 0
    for p in _iter_all_paragraphs(doc):
        try:
            name = p.style.name
        except Exception:
            continue
        if name.startswith("List Bullet") or name.startswith("List Number"):
            try:
                p.style = lp
                renamed += 1
            except Exception:
                pass
    if renamed:
        logger.debug(f"{LOG_PREFIX} relabeled {renamed} list paragraphs to 'List Paragraph'")


def _infer_anchor_from_doc(
    doc: _DocxDocument,
    before_ids: set[int],
    after_paragraphs: list[Paragraph],
) -> Optional[Tuple[str, int]]:
    """
    Find the anchor paragraph (immediately before the first newly inserted paragraph),
    then infer (family, ilvl) from its style name. Returns None if not found.
    """
    # Find index of first newly added paragraph by comparing underlying element ids
    first_new_idx: Optional[int] = None
    for idx, p in enumerate(after_paragraphs):
        try:
            pid = id(p._p)  # noqa: SLF001
        except Exception:
            continue
        if pid not in before_ids:
            first_new_idx = idx
            break

    if first_new_idx is None:
        return None  # nothing new inserted; nothing to shift

    anchor_idx = first_new_idx - 1
    if anchor_idx < 0:
        return None

    anchor_p = after_paragraphs[anchor_idx]
    try:
        style_name = anchor_p.style.name
    except Exception:
        return None

    fam_lvl = _style_name_to_family_and_level(style_name)
    if fam_lvl:
        logger.debug(
            f"{LOG_PREFIX} anchor paragraph detected: style='{style_name}' "
            f"-> family={fam_lvl[0]} ilvl={fam_lvl[1]}"
        )
    else:
        logger.debug(
            f"{LOG_PREFIX} anchor paragraph detected but not a list style: style='{style_name}'"
        )
    return fam_lvl


def _sync_style_name_with_level(
    doc: _DocxDocument,
    anchor: Optional[Tuple[str, int]] = None,
) -> None:
    """
    Ensure that the style name reflects each paragraph's effective ilvl.
    With RELATIVE_TO_ANCHOR_LEVEL=True, shift ilvl(s) by the anchor's ilvl
    (optionally only when family matches), then map to the correct style name.

    NOTE: This does NOT modify numbering ilvl (numPr.ilvl), only the attached style.
    """
    fixed = 0
    anchor_family = anchor[0] if anchor else None
    anchor_ilvl = anchor[1] if anchor else 0

    for p in _iter_all_paragraphs(doc):
        # Must be a real list para
        try:
            ppr = p._p.pPr  # noqa: SLF001
        except Exception:
            continue
        if ppr is None or ppr.numPr is None or ppr.numPr.ilvl is None:
            continue

        # Read actual ilvl from numbering
        try:
            ilvl = int(ppr.numPr.ilvl.val)  # 0..8
        except Exception:
            continue

        # Determine current family from its style
        try:
            name = p.style.name
        except Exception:
            continue

        fam_lvl = _style_name_to_family_and_level(name)
        if not fam_lvl:
            # Non-list styles are ignored to avoid misclassification
            continue

        family_current, _ = fam_lvl

        # Compute effective (possibly shifted) ilvl
        effective_ilvl = ilvl
        if RELATIVE_TO_ANCHOR_LEVEL and anchor:
            if (not RELATIVE_ONLY_WHEN_FAMILY_MATCHES) or (family_current == anchor_family):
                effective_ilvl = max(0, min(8, ilvl + anchor_ilvl))

        target_style_name = _family_and_level_to_style_name(family_current, effective_ilvl)

        if name != target_style_name:
            s = _get_style(doc, target_style_name)
            if s is None:
                _ensure_list_styles(doc)
                s = _get_style(doc, target_style_name)
            try:
                p.style = s
                fixed += 1
            except Exception:
                pass

    if fixed:
        logger.debug(
            f"{LOG_PREFIX} synced {fixed} list paragraph style(s) to match "
            f"{'relative ' if RELATIVE_TO_ANCHOR_LEVEL and anchor else ''}list level(s)"
        )


# ---------- public API ----------

def ensure_html_wrapper_initialized() -> None:
    """Kept for API parity; nothing to initialize."""
    return


def add_html_wrapper(doc_like: Any, html: str) -> None:
    """
    Convert HTML to Word using html-for-docx only:
      1) unwrap docxtpl Subdoc -> python-docx Document
      2) normalize Quill list indents to nested UL/OL and strip orphan anchors
      3) ensure 'List Bullet*'/'List Number*' exist (based on 'List Paragraph')
      4) detect anchor (paragraph before first inserted paragraph) for relative list shift
      5) run html-for-docx
      6) (optional) legacy relabel to 'List Paragraph' [DISABLED]
      7) (optional) re-sync style names to (possibly relative) list levels (safe)
    """
    if html is None:
        html = ""

    real_doc = _unwrap_to_docx_document(doc_like)

    # Normalize Quill's ql-indent-N → true nested lists; strips empty <a>
    html_in = normalize_quill_lists(html)

    # Guarantee styles html-for-docx will look up actually exist
    _ensure_list_styles(real_doc)

    # Snapshot 'before' paragraph element ids to locate anchor later
    before_paras = list(_iter_all_paragraphs(real_doc))
    before_ids = set()
    for p in before_paras:
        try:
            before_ids.add(id(p._p))  # noqa: SLF001
        except Exception:
            pass

    # Convert
    _parser.add_html_to_document(html_in, real_doc)
    logger.debug(f"{LOG_PREFIX} html-for-docx conversion complete")

    # Determine anchor (paragraph just before first inserted paragraph)
    after_paras = list(_iter_all_paragraphs(real_doc))
    anchor = _infer_anchor_from_doc(real_doc, before_ids, after_paras) if RELATIVE_TO_ANCHOR_LEVEL else None

    # Do NOT flatten to 'List Paragraph' unless explicitly forced.
    if FORCE_LIST_PARAGRAPH_STYLE:
        _relabel_list_styles_to_list_paragraph(real_doc)

    # Keep style names aligned with effective (possibly relative) levels.
    if SYNC_STYLE_TO_LEVEL:
        _sync_style_name_with_level(real_doc, anchor=anchor)
