import os
import re
from typing import Optional, Dict, Any
from docx import Document
from docx.shared import Mm
from PIL import Image
from .constants import IMAGE_SIZE_LIMITS, logger, LOG_PREFIX

IMAGE_MARKER_RE = re.compile(r"\[\[\s*[Ii]mage:?\s*([^\]]+)\s*\]\]")

def get_scaled_dimensions(image_path: str, max_width_mm: float, max_height_mm: float):
    with Image.open(image_path) as img:
        img_width, img_height = img.size
        dpi = img.info.get("dpi", (96, 96))[0]
        width_mm = img_width / dpi * 25.4
        height_mm = img_height / dpi * 25.4
        width_scale = max_width_mm / width_mm
        height_scale = max_height_mm / height_mm
        scale = min(1, width_scale, height_scale)
        out_w, out_h = width_mm * scale, height_mm * scale
        logger.debug(f"{LOG_PREFIX} scale: px=({img_width}x{img_height}) dpi={dpi} -> {out_w:.2f}x{out_h:.2f}mm scale={scale:.3f}")
        return out_w, out_h

def get_image_path_from_context(context: Dict[str, Any], key: str) -> Optional[str]:
    def get_nested(ctx, k):
        keys = k.split(".")
        curr = ctx
        for p in keys:
            if isinstance(curr, dict) and p in curr:
                curr = curr[p]
            else:
                return None
        return curr if isinstance(curr, str) else None

    logger.debug(f"{LOG_PREFIX} image lookup for key={key!r}")
    val = get_nested(context, key)
    if val:
        return val
    if "data" in context and isinstance(context["data"], dict):
        val = get_nested(context["data"], key)
        if val:
            return val
    if key in context and isinstance(context[key], str):
        return context[key]
    if "data" in context and key in context["data"] and isinstance(context["data"][key], str):
        return context["data"][key]
    if key.lower() in context and isinstance(context[key.lower()], str):
        return context[key.lower()]
    if "data" in context and key.lower() in context["data"] and isinstance(context["data"][key.lower()], str):
        return context["data"][key.lower()]
    logger.warning(f"{LOG_PREFIX} image path not found for {key!r}")
    return None

def replace_image_markers(doc: Document, context: Dict[str, Any]) -> None:
    for paragraph in doc.paragraphs:
        matches = IMAGE_MARKER_RE.findall(paragraph.text)
        if not matches:
            continue
        logger.debug(f"{LOG_PREFIX} images: para matches={matches}")
        for match in matches:
            orig_key = match.strip()
            image_key = orig_key if orig_key.startswith("data.") else f"data.{orig_key}"
            image_path = get_image_path_from_context(context, image_key)
            if not image_path or not os.path.isfile(image_path):
                logger.error(f"{LOG_PREFIX} missing image path for {image_key}")
                continue
            marker_text = f"[[ Image: {orig_key} ]]"
            paragraph.text = paragraph.text.replace(marker_text, "")

            run = paragraph.add_run()
            short_key = image_key.replace("data.", "")
            if short_key in IMAGE_SIZE_LIMITS:
                max_w, max_h = IMAGE_SIZE_LIMITS[short_key]
                width_mm, height_mm = get_scaled_dimensions(image_path, max_w, max_h)
                run.add_picture(image_path, width=Mm(width_mm), height=Mm(height_mm))
                logger.info(f"{LOG_PREFIX} inserted image key={image_key} size={width_mm:.1f}x{height_mm:.1f}mm")
            else:
                run.add_picture(image_path)
                logger.info(f"{LOG_PREFIX} inserted image key={image_key} default size")
