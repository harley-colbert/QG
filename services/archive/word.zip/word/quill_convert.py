from typing import Any, Dict, List, Tuple, Union
from .constants import logger, LOG_PREFIX

def looks_like_quill_delta(s: str) -> bool:
    test = s.strip()
    looks = test.startswith("{") and '"ops"' in test
    logger.debug(f"{LOG_PREFIX} looks_like_quill_delta: looks={looks} sample={test[:80].replace(chr(10),' ')}...")
    return looks


def delta_to_html(delta: Union[str, Dict[str, Any]]) -> str:
    """
    Convert a Quill delta to HTML with *true* nested UL/OL structure.

    Key points:
      - Block attributes (list/indent, header, quote, code-block, align, etc.)
        are carried on the *newline* op. We attach those attrs to the line being
        flushed at that newline.
      - We build lines as (segments, block_attrs). Each 'segment' keeps inline attrs.
      - Lists are nested by indent (0-based) -> depth = indent + 1.
      - Child <ul>/<ol> is emitted *inside the previous <li>*, not as a sibling.
      - Consecutive children at the same depth are grouped in a single <ul>/<ol>.
    """
    import json

    logger.debug(f"{LOG_PREFIX} delta_to_html: begin type={type(delta).__name__}")
    if isinstance(delta, str):
        try:
            raw_preview = delta[:120].replace("\n", " ")
            logger.debug(f"{LOG_PREFIX} delta_to_html: str input preview={raw_preview!r}")
            delta = json.loads(delta)
            logger.debug(f"{LOG_PREFIX} delta_to_html: parsed JSON ok")
        except Exception as e:
            # Safe fallback: treat the whole string as plain paragraph text
            from .sanitize import strip_markup
            logger.warning(f"{LOG_PREFIX} delta_to_html: invalid JSON; fallback to escaped paragraph. err={e}")
            return f"<p>{strip_markup(delta)}</p>"

    ops: List[Dict[str, Any]] = list(delta.get("ops", []))
    logger.debug(f"{LOG_PREFIX} delta_to_html: ops_count={len(ops)}")

    # -------- 1) Build logical lines (segments + block attrs from newline) --------

    # A 'line' is {"segments": List[(text, inline_attrs)], "block": Dict[str, Any]}
    lines: List[Dict[str, Any]] = []
    cur_segments: List[Tuple[str, Dict[str, Any]]] = []

    def _flush_line(block_attrs: Dict[str, Any]):
        # drop trailing empty if truly empty & not a list item (we still want empty list items)
        lines.append({"segments": cur_segments.copy(), "block": dict(block_attrs or {})})
        cur_segments.clear()

    def _append_segment(text: str, inline_attrs: Dict[str, Any]):
        if not text:
            return
        # merge with previous if same inline attrs to keep html smaller
        if cur_segments and cur_segments[-1][1] == inline_attrs:
            cur_segments[-1] = (cur_segments[-1][0] + text, inline_attrs)
        else:
            cur_segments.append((text, inline_attrs))

    for idx, op in enumerate(ops):
        insert = op.get("insert", "")
        attrs = op.get("attributes", {}) or {}

        # Handle embeds inline (image, formula, etc.) as simple placeholders
        if isinstance(insert, dict):
            if "image" in insert:
                _append_segment(f'<img src="{insert["image"]}"/>', {})  # let html4docx swap later if desired
                logger.debug(f"{LOG_PREFIX} delta_to_html: op#{idx} embed image")
            else:
                _append_segment("[embed]", {})
                logger.debug(f"{LOG_PREFIX} delta_to_html: op#{idx} generic embed")
            continue

        # Split textual insert by newline; newline carries the *block* attrs
        text = str(insert)
        parts = text.split("\n")

        for pi, part in enumerate(parts):
            if pi < len(parts) - 1:
                # there is a newline after 'part' -> add segment with inline attrs,
                # then flush a line with *block* attrs from this op
                _append_segment(part, {k: v for k, v in attrs.items()
                                       if k in ("bold", "italic", "underline", "strike", "link", "code")})
                _flush_line(attrs)
            else:
                # tail without newline -> add segment, wait for a later newline or end
                _append_segment(part, {k: v for k, v in attrs.items()
                                       if k in ("bold", "italic", "underline", "strike", "link", "code")})

    # If the delta didn't end with a newline, flush t
